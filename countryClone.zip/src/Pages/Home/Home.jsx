import React, { useContext, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { fetchAllCountries } from "../../slices/countrySlice";
import CountryCard from "../../components/CountryCard/CountryCard";
import { PacmanLoader } from "react-spinners";
import { myContext } from "../../App";
import Header from "../../components/Header/Header";

const Home = () => {
  const dispatch = useDispatch();
  const { dark } = useContext(myContext);
  const { countries, loading, error } = useSelector((state) => state.countries);

  useEffect(() => {
    dispatch(fetchAllCountries());
  }, []);
  return (
    <>
      {/* Spinner start */}
      {!loading && !countries && error && (
        <div
          style={{
            height: "100vh",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <h1 style={{ color: "red", opacity: "0.7" }}>{error}</h1>
        </div>
      )}
      {!error && !countries && loading && (
        <div
          style={{
            height: "100vh",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <PacmanLoader color="rgb(20, 19, 19)" size={40} />
        </div>
      )}
      {/* Spinner end */}

      <div
        className="country-wrapper"
        style={{
          display: "flex",
          flexWrap: "wrap",
          justifyContent: "center",
          gap: "5px",
          marginTop: "50px",
        }}
      >
        {!loading &&
          !error &&
          countries &&
          countries.map((country) => (
            <CountryCard key={country.name} country={country} />
          ))}
      </div>
    </>
  );
};

export default Home;
