import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from 'axios'

const initialState = {
  countries: null,
  loading: false,
  error: false,
};
// {
//   return axios.get("https://restcountrie.com/v2/all").then((res) => (
//       res.data
//   )).catch((error) => {
//       return new Error(error.message)
//   }     
//   )
// }
export const fetchAllCountries = createAsyncThunk(
  "countries/fetchAllCountries",
  async () => {
    let res = await axios.get("https://restcountries.com/v2/all");
    return res.data;
  }
);

const countrySlice = createSlice({
  name: "countries",
  initialState,
  reducers: {},
  extraReducers : {
    [fetchAllCountries.pending] : (state, action) => {
        state.loading = true;
    },
    [fetchAllCountries.fulfilled] : (state, action) => {
        state.countries = action.payload;
        state.loading = false;
    },
    [fetchAllCountries.rejected] : (state, action) => {
        state.loading = false;
        // console.log(action.error.message)
        state.error = action.error.message;
    },
  }
});

export default countrySlice.reducer;
